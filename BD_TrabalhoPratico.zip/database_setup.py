import sqlite3


def insert_default_disciplina(file, conn):
    file = open(f"data/{file}", "r", encoding="utf8")
    line = file.readline()
    while line:
        line = file.readline().replace('"', '')
        line_splited = line.split(",") 

        cod_disc = line_splited[0]
        fk_depart = line_splited[len(line_splited)-1]
        aux = line[8:]
        nome = aux[:-5]
        
        try:
            conn.execute('''
            INSERT INTO Disciplina (cod, nome, fk_depart)
            VALUES (?, ?, ?)
        ''', (cod_disc, nome, fk_depart))    
        except sqlite3.Error as e:
            pass

def insert_default_turma(file, conn):
    file = open(f"data/{file}", "r", encoding="utf8")
    line = file.readline()
    while line:
        line = file.readline().replace('"', '')
        line_splited = line.split(",") #eliminar Cod, de line
        #print(line_splited)
        if len(line_splited) > 1:
            turma = line_splited[0]
            periodo = line_splited[1]
            prof = line_splited[2].split("(")
            horario = line_splited[3]
            vagas_ocup = line_splited[4]
            total_vagas = line_splited[5]
            local = line_splited[6]
            cod_disci= line_splited[7]
            cod_depart = line_splited[8].isdigit()
            #cod_depart = ''.join(c for c in line_splited[8] if c.isdigit())#cod_depart apenas digito de line[8]
            try:
                conn.execute('''
                INSERT INTO Turma (turma, periodo, prof, horario, vagas_ocupadas, vagas_total, local, cod_disciplina, cod_depart)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (turma, periodo, prof[0], horario, vagas_ocup, total_vagas, local, cod_disci, cod_depart))
                
                conn.execute('''
                INSERT INTO Professor (name,fk_cod_disc)
                VALUES (?, ?)
            ''', (prof[0],cod_disci))
                #print(prof[0],cod_disci)
            
            except sqlite3.Error as e:
                print("ERRO que ta rolando: ", e)
            

def insert_default_departamento(file, conn):
    file = open(f"data/{file}", "r", encoding="utf8")
    line = file.readline()
    while line:
        line = file.readline().replace('"', '')
        line_splited = line.split(",", 1) 
        if len(line_splited) > 1:
            cod_depart = line_splited[0]
            try:
                conn.execute('''
                    INSERT INTO Departamento (id, nome)
                    VALUES (?, ?)
                ''', (cod_depart, line_splited[1]))
            except sqlite3.Error as e:
                pass

    

def create_database():
    conn = sqlite3.connect('database.db')

    #Criar tabela Estudantes
    conn.execute('''
        CREATE TABLE IF NOT EXISTS Estudantes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT COLLATE NOCASE,
            email TEXT COLLATE NOCASE,
            matricula TEXT COLLATE NOCASE,
            curso TEXT COLLATE NOCASE,
            senha TEXT COLLATE NOCASE
        )
    ''')

    #Professores
    conn.execute('''
        CREATE TABLE IF NOT EXISTS Professor (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT COLLATE NOCASE,
            fk_cod_disc TEXT,
            FOREIGN KEY (fk_cod_disc) REFERENCES Disciplina(cod)
        )
    ''')

    #Criar tabela Disciplina
    conn.execute('''
        CREATE TABLE IF NOT EXISTS Disciplina (
            cod TEXT PRIMARY KEY,
            nome TEXT,
            fk_depart TXT,
            FOREIGN KEY (fk_depart) REFERENCES Departamento(id)
        )
    ''')

    #Criar tabela Turmas
    conn.execute('''
        CREATE TABLE IF NOT EXISTS Turma (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            turma TEXT COLLATE NOCASE,
            periodo TEXT COLLATE NOCASE,
            prof TEXT COLLATE NOCASE,
            horario TEXT COLLATE NOCASE,
            vagas_ocupadas TEXT,
            vagas_total TEXT,
            local TEXT COLLATE NOCASE,
            cod_disciplina TEXT,
            cod_depart TXT,
            FOREIGN KEY (cod_disciplina) REFERENCES Disciplina(cod),
            FOREIGN KEY (cod_depart) REFERENCES Departamento(id)
            
        )
    ''')

    #Criar tabela Departamento
    conn.execute('''
        CREATE TABLE IF NOT EXISTS Departamento (
            id TXT PRIMARY KEY ,
            nome TEXT
        )
    ''')
    #AVALIACAO
    conn.execute('''
        CREATE TABLE IF NOT EXISTS Avaliacao (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            prof TEXT,
            disciplina TEXT,
            comentario TEXT,
            nota INTERGER
        )
    ''')
    #denuncias
    conn.execute('''
        CREATE TABLE IF NOT EXISTS Denuncia (
            id INTEGER PRIMARY KEY,
            nome TEXT COLLATE NOCASE,
            disciplina TEXT COLLATE NOCASE,
            comentario TEXT COLLATE NOCASE,
            nota TEXT COLLATE NOCASE
        )
    ''')
    
    
  
        
    insert_default_departamento("depart.txt", conn)
    insert_default_turma("turmas.txt", conn)    
    insert_default_disciplina("discip.txt", conn)

    #Salvar as alterações e fechar a conexão
    conn.commit()
    conn.close()

