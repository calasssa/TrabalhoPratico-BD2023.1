#####################
#   D   E   F   S   |
#####################

from flask import Flask, render_template, request, redirect
import sqlite3 as sql
from database_setup import create_database
import os
import json

app = Flask(__name__)
create_database()

#Dados do adm
adm_email = "adm@unb.com"
adm_senha = "123456"

# Criar arquivo de login
def criar_dados_login(data):
    # Dados colocados no arquivo
    json_object = json.dumps(data, indent=4)
    with open("login.json", "w") as outfile:
        outfile.write(json_object)

# Verificar se o usuário está logado
def usuario_esta_logado():
    return os.path.isfile("login.json")

# Obter dados do usuario
def dados_do_usuario_logado():
    return json.load(open("login.json", "r"))

# Remover sessão de login
def remove_login():
    if usuario_esta_logado():
        os.remove("login.json")

#############################
#   I   N   I   C   I   O   #
#############################

# No começo a pessoa começa sem login.
remove_login()

#########################
#   R   O   T   A   S   #
#########################

'''
    Página inicial
'''

@app.route("/")
def hello_world():
    # Esta verificação irá mostrar
    # páginas diferentes dependendo se ele está
    # logado. Exemplo:
    #   Quando cadastrar e for para a rota "/register_action"
    #   ele irá logar o usuário cadastrado, e quando ele voltar
    #   para esta página, ele já vai estar logado.

    if usuario_esta_logado():
        # Pegar dados de login
        dados_de_login = dados_do_usuario_logado()

        return render_template(
            'pagina_logado.html',
            dados = dados_de_login
        )
    else:
        return render_template('home.html')

################
#    CADASTRO
# "/register" -> Rota que exibe página de cadastro
# "/register_action" -> Rota que recebe formulário da página de cadastro
#################
@app.route("/register")
def register():
    return render_template('cadastro.html')

@app.route("/register_action", methods = ['POST', 'GET'])
def register_action():
    if request.method == 'POST':
        try:
            # Obter dados definidos em "cadastro.html"
            name = request.form['name']
            email = request.form['email']
            matricula = request.form['matricula']
            curso = request.form['curso']
            senha = request.form['senha']

            # Inserir dados
            with sql.connect("database.db") as con:
                # Inserir no banco de dados
                cursor = con.cursor()

                cursor.execute('''
                    INSERT INTO Estudantes (name, email, matricula, curso, senha)
                    VALUES (?, ?, ?, ?, ?)
                ''', (name, email, matricula, curso, senha))

                con.commit()
        except:
            con.rollback()
            print("Erro de cadastro")

        finally:
            # Logar a pessoa após cadastrar
            dados_logado = {
                "nome": name,
                "email": email,
                "senha": senha,
                "curso": curso,
                "matricula": matricula
            }

            criar_dados_login(dados_logado)

            # Este programa ira renderizar "cadastro_resultado.html"
            # e ira enviar a variavel "nome" para ela.
            return render_template("cadastro_resultado.html", nome = name)
            con.close()


#################
#  PAGINA LOGIN
#    "/login"         -> Página de Login
#    "/login_action"  -> Página que recebe os dados da rota "/login"
#    "/sair"          -> Saida do login  
#################
@app.route("/login")
def login():
    return render_template('login.html')

@app.route("/login_action", methods = ['POST', 'GET'])
def login_action():
    login_data = None

    if request.method == 'POST':
        try:
            # Obter dados definidos em "login.html"
            email = request.form['email']
            senha = request.form['senha']
            #tipo_conta = request.form['tipo_conta']

            # Obter dados
            with sql.connect("database.db") as con:
                cursor = con.cursor()
                con.row_factory = sql.Row

                # cursor.execute('''
                #     SELECT * FROM Estudantes WHERE email = "{email}" AND senha = "{senha}"
                # ''')
                cursor.execute("SELECT * FROM Estudantes WHERE email =? AND senha =?", (email,senha,))

                output = cursor.fetchall()
                #print(output)

                # Verificar se obteve usuario e pegar seus dados
                if len(output) >= 1:
                    login_data = {
                        "nome": output[0][1],
                        "email": output[0][2],
                        "matricula": output[0][3],
                        "curso": output[0][4],
                        "senha": output[0][5]
                    }

                print(login_data)

                con.commit()
                con.close
        except:
            con.rollback()

        finally:
            if login_data != None:
                criar_dados_login(login_data)
                # Vai para a página inicial se um usuario for encontrado
                return redirect("/")
            else:
                if email == adm_email:
                    if senha == adm_senha:
                        return render_template("login_adm.html")
                return render_template("login_erro.html")

@app.route("/sair")
def exit():
    remove_login()
    return redirect("/")# Redireciona para a rota de login

##############
# PAGINA LOGIN - ESTUDANTE
##############
###### AVALIAR PROFESSOR: fazer avaliação, deletar conta, update de dados
@app.route("/fazer_avaliacao")
def avaliarprof():
    return render_template('avaliar.html')

@app.route("/avaliar_action", methods = ['POST', 'GET'])
def avaliar_action():
    if request.method == 'POST':
        try:
            # if usuario_esta_logado:
            #     print("estalogado")       
            prof = request.form['prof']
            disciplina = request.form['disciplina']           
            nota = int(request.form['pts'])
            coment = request.form['coment']
            #print(prof, disciplina, nota, coment)
            with sql.connect("database.db") as con:
                # Inserir no banco de dados
                cursor = con.cursor()
                print(prof, disciplina, nota, coment)
                cursor.execute('''
                    INSERT INTO Avaliacao (prof, disciplina, comentario, nota)
                    VALUES (?, ?, ?, ?)
                ''',(prof, disciplina, coment, nota))
                con.commit()
        except sql.Error as e:
            print("ERRO que ta rolando: ", e)

        finally:
            return render_template("avaliacao_reg.html")
            con.close()

##### DELETAR PROPRIA CONTA
@app.route("/deletar_conta")
def delete_action():
    if usuario_esta_logado():
        dados_de_login = dados_do_usuario_logado()
    else:
        return render_template('erro_delete.html')
    
    email = dados_de_login["email"]
    senha = dados_de_login["senha"]
    try:
        with sql.connect("database.db") as con:
            cursor = con.cursor()
            print(email) 
            cursor.execute("DELETE FROM Estudantes WHERE email =? AND senha=?", (email,senha,))
            con.commit()
    except:
        print("erro de delete")
        #con.rollback()
    finally:
        remove_login()
        return redirect("/")

##### ALTERAR DADOS DO PERFIL
@app.route("/cadastro_update")
def cadastro_update():
    return render_template('cadastro_change.html')

@app.route('/cadastro_update_action', methods = ['POST', 'GET'])
def cadastro_update_action():
    if usuario_esta_logado():
        dados_de_login = dados_do_usuario_logado()
    if request.method == 'POST':
        try:
            #Obter dados definidos em "cadastro.html"
            senha_new = request.form['senha']
            senha_old = dados_de_login['senha']
            print(senha_new, dados_de_login['email'], senha_old)
            with sql.connect("database.db") as con:
                cursor = con.cursor()
                cursor.execute('''UPDATE Estudantes 
                                SET senha = ?
                                WHERE email = ? AND senha = ?''', (senha_new, dados_de_login['email'], senha_old))
                con.commit()
        except sql.Error as e:
            print("ERRO que ta rolando: ", e)
            con.rollback()
            print("Erro de mudanca de senha")

        finally:
            return render_template("senha_atualizada.html")

##############
# PAGINAS DE LISTAGEM
##############

@app.route('/list_depart')
def list_dpt():
   con = sql.connect("database.db")
   con.row_factory = sql.Row
   cur = con.cursor()
   cur.execute("select * from Departamento")
   rows = cur.fetchall()
   con.commit()

   return render_template("list_depart.html", rows = rows)

@app.route('/list_discip')
def list_discip():
   con = sql.connect("database.db")
   con.row_factory = sql.Row
   cur = con.cursor()
   cur.execute("select * from Disciplina")
   rows = cur.fetchall()
   con.commit()
   return render_template("list_discip.html", rows = rows)

@app.route('/list_prof')
def list_prof():
   con = sql.connect("database.db")
   con.row_factory = sql.Row
   cur = con.cursor()
   cur.execute("select name, fk_cod_disc from Professor")
   rows = cur.fetchall()
   con.commit()
   return render_template("list_prof.html", rows = rows)

@app.route('/list_avaliacoes')
def list_avaliacao():
   con = sql.connect("database.db")
   con.row_factory = sql.Row
   cur = con.cursor()
   cur.execute("select * from Avaliacao")
   rows = cur.fetchall()
   con.commit()
   return render_template("list_avaliacao.html", rows = rows)




if __name__ == '__main__':
   app.run(debug = True)
